// todo: this should be generated at build time.
module.exports = '0.10.1';
