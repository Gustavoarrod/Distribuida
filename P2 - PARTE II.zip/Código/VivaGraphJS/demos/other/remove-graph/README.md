# Remove graph

This demo shows how to completely remove graph from the DOM.

# How it is done?

``` js
// renderer is created as Viva.Graph.View.renderer()
// if you no longer need it just call:
renderer.dispose();
```

[See online demo](http://anvaka.github.io/VivaGraphJS/demos/other/remove-graph/)
