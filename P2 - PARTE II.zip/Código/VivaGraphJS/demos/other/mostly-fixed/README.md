# Mostly Fixed

This is just a small demo which makes all nodes of the graph fixed (they are not
moved during layout), and then adds more nodes which can fly anywhere.

[Demo](http://anvaka.github.io/VivaGraphJS/demos/other/mostly-fixed/)

**Note:** If you already know all positions for nodes, and there is no dynamic
movement required, consider using [constant layout](https://github.com/anvaka/VivaGraphJS/blob/master/demos/other/constantLayout.html)
